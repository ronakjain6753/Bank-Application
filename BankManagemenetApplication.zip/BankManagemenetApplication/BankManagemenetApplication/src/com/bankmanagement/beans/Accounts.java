package com.bankmanagement.beans;

//Declaring private variable
public class Accounts {
	private long accNo;
	private String custName;
	private long mobile;
	private String accType;
	private String branch;
	private double balance;

	public Accounts() {
		
	}
	
//	Required Getter and Setter Functions
	public long getAccNo() {
		return accNo;
	}
	/**
	 * @param accNo the accNo to set
	 */
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	/**
	 * @return the custName
	 */
	public String getCustName() {
		return custName;
	}
	/**
	 * @param custName the custName to set
	 */
	public void setCustName(String custName) {
		this.custName = custName;
	}
	/**
	 * @return the mobile
	 */
	public long getMobile() {
		return mobile;
	}
	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	/**
	 * @return the accType
	 */
	public String getAccType() {
		return accType;
	}
	/**
	 * @param accType the accType to set
	 */
	public void setAccType(String accType) {
		this.accType = accType;
	}
	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}
	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}
	/**
	 * @return the branch
	 */
	public double getBalance() {
		return balance;
	}
	/**
	 @param the balance to set
	 */
	public void setBalance(double balance) {
		this.balance = balance;
	}
	/**
	 * @return the balance
	 */
	
	public Accounts(long accNo, String custName, long mobile, String accType, String branch, double balance) {
		super();
		this.accNo = accNo;
		this.custName = custName;
		this.mobile = mobile;
		this.accType = accType;
		this.branch = branch;
		this.balance = balance;
	}
	
	@Override
	public String toString() {
		return " Account Number= " + accNo + "\n Customer Name=" + custName + "\n Mobile=" + mobile + "\n Account Type=" + accType
				+ "\n Branch=" + branch + "\n Balance=" + balance;
	}
}
