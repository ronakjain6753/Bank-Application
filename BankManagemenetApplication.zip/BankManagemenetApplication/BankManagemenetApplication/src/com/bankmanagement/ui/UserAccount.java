package com.bankmanagement.ui;

import java.util.Date;
import java.util.Scanner;

import com.bankmanagement.beans.Accounts;
import com.bankmanagement.beans.Transactions;
import com.bankmanagement.exceptions.AccountNotFound;
import com.bankmanagement.exceptions.NotEnoughBalance;
import com.bankmanagement.service.AccountClientService;
import com.bankmanagement.service.AccountClientServiceImpl;
import com.bankmanagement.service.TransService;
import com.bankmanagement.service.TransServiceImpl;

public class UserAccount {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		// Declaring Variables
		long accNo = 1000;
		String userName;
		long mobileNo;
		String accType;
		String branch;
		double balance;
		int custId = 100;
		long accNoFrom;
		long accNoTo;
		double amount;
		Date dateOfTrans;

		Accounts account = null;
		Transactions transaction = null;
		AccountClientService service = new AccountClientServiceImpl();
		TransService transService = new TransServiceImpl();

//		Showing Options to User
		while (true) {
			System.out.println("--------BANK ACCOUNT MANAGEMENT SYSTEM--------");
			System.out.println("1. Create new account");
			System.out.println("2. Deposit");
			System.out.println("3. Withdraw");
			System.out.println("4. Show customer details");
			System.out.println("5. Fund transfer");
			System.out.println("6. Show Transaction Details");
			System.out.println("7. Exit application");
			System.out.println("Enter your choice: ");
			int choice = sc.nextInt();

			// Based on user's choice using switch case
			switch (choice) {

			// Creating Account
			case 1:
				System.out.println("----CREATE NEW ACCOUNT----");
				System.out.println("Enter Your Name: ");
				userName = sc.next();
				System.out.println("Enter Your Mobile Number: ");
				mobileNo = sc.nextLong();
				System.out.println("Enter Account Type :- Saving/Checking : ");
				accType = sc.next();
				System.out.println("Enter Bank Branch: ");
				branch = sc.next();
				balance = 1000;
				accNo++;
				account = new Accounts(accNo, userName, mobileNo, accType, branch, balance);
				System.out.println(service.addAccount(account) + " with Account Number " + accNo);
				break;

			// Deposit money into account
			case 2:
				System.out.println("----DEPOSIT----");
				System.out.println("Enter Account Number in which you want to deposit: ");
				long dpAccNo = sc.nextLong();
				try {
					System.out.println(service.getAccount(dpAccNo));
					System.out.println("Enter amount you wish to deposit: ");
					double dpAmount = sc.nextDouble();
					System.out.println("Your Old Balance is : " + service.getAccount(dpAccNo).getBalance());
					service.depositIntoBalance(dpAccNo, dpAmount);
					System.out.println("Your New Balance is : " + service.getAccount(dpAccNo).getBalance());
				} catch (AccountNotFound anf) {
					System.out.println("Oops!! Account Number is Invalid... Try Again");
				}
				break;
			// Withdraw money from account
			case 3:
				System.out.println("----WITHDRAW----");
				System.out.println("Enter Your Account Number: ");
				long wdAccNo = sc.nextLong();
				try {
					System.out.println(service.getAccount(wdAccNo));
					System.out.println("Enter Amount You Want to Withdraw: ");
					double wdAmount = sc.nextDouble();
					if (wdAmount <= (service.getAccount(wdAccNo).getBalance())) {
						System.out.println("Your Old Balance Was : " + service.getAccount(wdAccNo).getBalance());
						service.withdrawFromBalance(wdAccNo, wdAmount);
						System.out.println("Your New Balance Is : " + service.getAccount(wdAccNo).getBalance());
						System.out.println("Thanks For Visiting!!!");
					} else {
						throw new NotEnoughBalance("Oops!! Not Enough Balance");
					}
				} catch (AccountNotFound anf) {
					System.out.println("Oops!! Account Number is Invalid... Try Again");
				} catch (NotEnoughBalance neb) {
					System.out.println("Oops!! Not Enough Balance...");
				}
				break;

			// Displaying details of the user account
			case 4:
				System.out.println("----SHOW DETAILS----");
				System.out.println("Enter account number to show details: ");
				long accNoQuery = sc.nextLong();
				try {
					System.out.println(service.getAccount(accNoQuery));
				} catch (AccountNotFound anf) {
					System.out.println("Kindly Enter a valid account number....");
				}
				break;

			// Transferring money from one account to another
			case 5:
				System.out.println("----FUND TRANSFER----");
				System.out.println("Enter your account number to start transaction: ");
				long transFromAcc = sc.nextLong();
				try {
					System.out.println(service.getAccount(transFromAcc));
					System.out.println("Enter beneficiary account number: ");
					long neftAccNo = sc.nextLong();
					try {
						service.getAccount(neftAccNo);
					} catch (AccountNotFound anf) {
						System.out.println("Wrong Account Number of beneficiary... Transaction Cancelled...");
					}
					System.out.println("Enter Amount to transfer: ");
					double neftAmount = sc.nextDouble();

					try {
						double transWithdrawAmount = neftAmount;
						if (transWithdrawAmount <= (service.getAccount(transFromAcc).getBalance())) {
							System.out.println("Old Balance of " + transFromAcc + " is "
									+ service.getAccount(transFromAcc).getBalance());
							service.withdrawFromBalance(transFromAcc, transWithdrawAmount);
							System.out.println("New Balance of " + transFromAcc + " is "
									+ service.getAccount(transFromAcc).getBalance());
						} else {
							throw new NotEnoughBalance("Not enough Balance");
						}
					} catch (NotEnoughBalance neb) {
						System.out.println("Not enough Balance");
						break;
					}

					try {
						double transDepositAmount = neftAmount;
						System.out.println(
								"Old Balance of " + neftAccNo + " is " + service.getAccount(neftAccNo).getBalance());
						service.depositIntoBalance(neftAccNo, transDepositAmount);
						System.out.println(
								"New Balance of " + neftAccNo + " is " + service.getAccount(neftAccNo).getBalance());
					} finally {
						accNoFrom = transFromAcc;
						accNoTo = neftAccNo;
						amount = neftAmount;
						dateOfTrans = new Date();
						balance = service.getAccount(transFromAcc).getBalance();
						transaction = new Transactions(custId, accNoFrom, accNoTo, amount, dateOfTrans,
								balance);
						custId++;
						transService.addTransaction(transFromAcc, neftAccNo, transaction);
						System.out.println(service.getAccount(transFromAcc));
					}

				} catch (AccountNotFound anf) {
					System.out.println("Enter valid account number...");
				}
				break;

			// Showing Account Transaction Details
			case 6:
				System.out.println("----SHOW ACCOUNT TRANSACTIONS DETAILS----");
				System.out.println("Enter account number to show transactions: ");
				long showTransAccNo = sc.nextLong();
				try {
					service.getAccount(showTransAccNo);
					System.out.println(transService.getTransForAccNo(transaction, showTransAccNo));
				} catch (AccountNotFound anf) {
					System.out.println("Oops!! Enter a valid account number....");
				}
				break;

			// Exit the Application
			case 7:
				System.out.println("Thank You For Visiting!!");
				sc.close();
				System.exit(0);
				break;
			default:
				System.out.println("Please Choose a Valid Option!!");
			}
		}
	}
}
