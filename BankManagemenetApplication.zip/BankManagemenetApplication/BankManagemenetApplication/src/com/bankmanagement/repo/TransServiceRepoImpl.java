package com.bankmanagement.repo;

import java.util.ArrayList;
import java.util.HashMap;

import com.bankmanagement.beans.Transactions;

public class TransServiceRepoImpl implements TransServiceRepo{

	HashMap<Long, Transactions> clientAccTransactions = new HashMap<Long, Transactions>();
	ArrayList<String> allTrans = new ArrayList<String>();
	
	//Implementation of Transaction 
	@Override
	public String addTransaction(long transFromAcc, long neftAccNo, Transactions transaction) {
		
		clientAccTransactions.put(transFromAcc, transaction);
		clientAccTransactions.put(neftAccNo, transaction);
		
		System.out.println("Successfully transferred from " + transFromAcc + " to " + neftAccNo 
				+ " with TransactionID " + transaction.getTransId());
		
		return "Transaction Added to Account Transaction History";
	}
	
	@Override
	public ArrayList<String> getTransForAccNo(Transactions transaction, long showTransAccNo) {
		
		while(true) {
			if (transaction.getAccNoFrom() == showTransAccNo) {
				allTrans.add(transaction.toString());
			}
			if (transaction.getAccNoTo() == showTransAccNo) {
				allTrans.add(transaction.toString());
			}
			return allTrans;
		}
	}

}
