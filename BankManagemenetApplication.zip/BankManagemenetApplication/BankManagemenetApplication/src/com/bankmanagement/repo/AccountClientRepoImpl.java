package com.bankmanagement.repo;

import java.util.HashMap;

import com.bankmanagement.beans.Accounts;
import com.bankmanagement.exceptions.AccountNotFound;
import com.bankmanagement.exceptions.NotEnoughBalance;

public class AccountClientRepoImpl implements AccountClientRepo {

	HashMap<Long, Accounts> userAccount = new HashMap<Long, Accounts>();

	//Function to add user account
	@Override
	public String addAccount(Accounts accounts) {
		userAccount.put(accounts.getAccNo(), accounts);
		return "Account Added Successfully!";
	}
	
	//Function to get user account
	@Override
	public Accounts getAccount(long getAcc) throws AccountNotFound {
		if (userAccount.containsKey(getAcc)) {
			return userAccount.get(getAcc);
		} else {
			throw new AccountNotFound("Oops!! Account Number is Invalid... Try Again");
		}
	}
	
	//Function to withdraw amount
	@Override
	public void withdrawFromBalance(long getAcc, double withdrawAmount) throws NotEnoughBalance{

		if (userAccount.containsKey(getAcc) && (userAccount.get(getAcc).getBalance() - withdrawAmount) > -1) {
			userAccount.get(getAcc).setBalance(userAccount.get(getAcc).getBalance() - withdrawAmount);
		}
		else {
			throw new NotEnoughBalance("Not enough Balance");
		}
	}
	
	//Function to deposit amount
	@Override
	public void depositIntoBalance(long getAcc, double depositAmount) {

		if (userAccount.containsKey(getAcc)) {
			userAccount.get(getAcc).setBalance(userAccount.get(getAcc).getBalance() + depositAmount);
		}
	}

}
