package com.bankmanagement.exceptions;

//Throwing Exception
public class AccountNotFound extends Exception{
	public AccountNotFound(String message) {
		super(message);
	}
}
