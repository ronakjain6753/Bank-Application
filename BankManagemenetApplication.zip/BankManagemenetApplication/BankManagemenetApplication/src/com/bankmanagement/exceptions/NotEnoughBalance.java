package com.bankmanagement.exceptions;

//Throwing Exception
public class NotEnoughBalance extends Exception {
	public NotEnoughBalance(String message) {
		super(message);
	}
}
