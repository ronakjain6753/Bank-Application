package com.bankmanagement.service;

import com.bankmanagement.beans.Accounts;
import com.bankmanagement.exceptions.AccountNotFound;
import com.bankmanagement.exceptions.NotEnoughBalance;

//Creating Interface
public interface AccountClientService {
	public abstract String addAccount(Accounts account);

	public abstract Accounts getAccount(long getAcc) throws AccountNotFound;
	
	public abstract void withdrawFromBalance(long getAcc, double withdrawAmount) throws NotEnoughBalance;

	public abstract void depositIntoBalance(long getAcc, double depositAmount);
}
