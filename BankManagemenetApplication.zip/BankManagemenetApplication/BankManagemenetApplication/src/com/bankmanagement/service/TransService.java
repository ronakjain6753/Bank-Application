package com.bankmanagement.service;

import java.util.ArrayList;

import com.bankmanagement.beans.Transactions;

//Creating Interface
public interface TransService {
	public abstract String addTransaction(long transFromAcc, long neftAccNo, Transactions transaction);
	
	public abstract ArrayList<String> getTransForAccNo(Transactions transaction, long showTransAccNo);
}
