package com.bankmanagement.service;

import com.bankmanagement.beans.Accounts;
import com.bankmanagement.exceptions.AccountNotFound;
import com.bankmanagement.exceptions.NotEnoughBalance;
import com.bankmanagement.repo.AccountClientRepo;
import com.bankmanagement.repo.AccountClientRepoImpl;

public class AccountClientServiceImpl implements AccountClientService {
	AccountClientRepo dao = new AccountClientRepoImpl();

	@Override
	public String addAccount(Accounts account) {
		return dao.addAccount(account);

	}

	@Override
	public Accounts getAccount(long getAcc) throws AccountNotFound {
		return dao.getAccount(getAcc);

	}

	@Override
	public void withdrawFromBalance(long getAcc, double withdrawAmount) throws NotEnoughBalance {
		
		dao.withdrawFromBalance(getAcc, withdrawAmount);
	}
	
	@Override
	public void depositIntoBalance(long getAcc, double depositAmount) {
		
		dao.depositIntoBalance(getAcc, depositAmount);
	}

}
