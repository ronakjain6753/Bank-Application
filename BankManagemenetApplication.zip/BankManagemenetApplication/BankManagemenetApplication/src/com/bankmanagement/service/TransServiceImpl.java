package com.bankmanagement.service;

import java.util.ArrayList;

import com.bankmanagement.beans.Transactions;
import com.bankmanagement.repo.TransServiceRepo;
import com.bankmanagement.repo.TransServiceRepoImpl;


public class TransServiceImpl implements TransService {
	TransServiceRepo dao = new TransServiceRepoImpl();
	
	@Override
	public String addTransaction(long transFromAcc, long neftAccNo, Transactions transaction) {
		return dao.addTransaction(transFromAcc, neftAccNo, transaction);
	}

	@Override
	public ArrayList<String> getTransForAccNo(Transactions transaction, long showTransAccNo) {
		return dao.getTransForAccNo(transaction, showTransAccNo);
	}

}
